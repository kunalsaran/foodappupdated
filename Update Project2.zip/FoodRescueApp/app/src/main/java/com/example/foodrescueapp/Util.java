package com.example.foodrescueapp;

public class Util {

    public static final int DATABASE_VERSION = 7;
    public static final String DATABASE_NAME = "user_db1";
    public static final String TABLE_NAME = "users";

    public static final String USER_ID= "user_id";
    public static final String USERNAME= "username";
    public static final String PASSWORD = "password";
    public static final String EMAIL = "email";
    public static final String PHONENO = "phoneNo";
    public static final String ADDRESS = "address";

    public static final String TABLE_NAME6 = "food";

    public static final String FOOD_ID= "food_id";
    public static final String FOOD_TITLE= "food_title";
    public static final String FOOD_DESC = "food_desc";
    public static final String FOOD_DATE = "food_date";
    public static final String FOOD_PCK_TIME = "food_pck_time";
    public static final String FOOD_QNT = "food_qnt";
    public static final String FOOD_LOC = "food_loc";
    public static final String FOOD_IMG = "food_img";

    public static final String TABLE_NAME2 = "sharedFood";

    public static final String TABLE_NAME3 = "admin";

    public static final String USER_ID1 = "user_id1";
    public static final String USERNAME1 = "username1";
    public static final String PASSWORD1 = "password1";
    public static final String EMAIL1 = "email1";
    public static final String PHONENO1 = "phoneNo1";
    public static final String ADDRESS1 = "address1";

    public static final String TABLE_NAME4 = "sales";

    public static final String USER_ID2 = "user_id2";
    public static final String USERNAME2 = "username2";
    public static final String PASSWORD2 = "password2";
    public static final String EMAIL2 = "email2";
    public static final String PHONENO2 = "phoneNo2";
    public static final String ADDRESS2 = "address2";

}
